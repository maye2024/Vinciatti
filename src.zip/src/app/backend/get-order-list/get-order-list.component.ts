import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-get-order-list',
  templateUrl: './get-order-list.component.html',
  styleUrls: ['./get-order-list.component.scss'],
  standalone: false,
})
export class GetOrderListComponent {

  constructor() { }

}
