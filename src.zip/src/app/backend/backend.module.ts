import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { InventoryComponent } from './inventory/inventory.component';
import { GetOrderListComponent } from './get-order-list/get-order-list.component';
import { IonicModule } from '@ionic/angular';

import { AppRoutingModule } from '../app-routing.module';

@NgModule({
  declarations: [InventoryComponent, GetOrderListComponent],
  imports: [
    CommonModule, IonicModule.forRoot(), AppRoutingModule,
  ]
})
export class BackendModule { }
